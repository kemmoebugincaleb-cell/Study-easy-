# study-easy — LMS (Learning Management System)

## Architecture

- **Frontend** : HTML / CSS / JavaScript (Vanilla, appels AJAX via `fetch`)
- **Backend** : PHP (API REST simple, un fichier par action, dans `php/api/`)
- **Base de données principale** : MySQL (`php/database.sql`) — utilisateurs, cours, modules, évaluations, notes, progression, certificats
- **Stockage des PDF** : Neon (PostgreSQL serverless) — table `documents_pdf` (BYTEA), créée automatiquement au premier upload
- **Stockage des vidéos** : Cloudinary — upload signé via l'API REST Cloudinary (`resource_type=video`)
- **Certificats + QR code** : génération HTML/CSS (thème bleu nuit) + QR code via l'API publique `api.qrserver.com` (pas de dépendance PHP à installer)

⚠️ Note importante : Neon est un service **PostgreSQL**, pas MySQL. Le sujet demandait MySQL "en priorité", donc MySQL héberge toutes les données relationnelles, et Neon (Postgres) est utilisé spécifiquement et uniquement pour stocker le contenu binaire des PDF, comme demandé.

## Installation

1. **Base MySQL**
   ```bash
   mysql -u root -p < php/database.sql
   ```

2. **Configurer les accès** dans `php/config.php` (ou via variables d'environnement) :
   - `MYSQL_HOST`, `MYSQL_DB`, `MYSQL_USER`, `MYSQL_PASS`
   - `NEON_HOST`, `NEON_DB`, `NEON_USER`, `NEON_PASS` (fournis par votre projet Neon)
   - `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`

3. **Serveur PHP** (nécessite l'extension `pdo_mysql`, `pdo_pgsql`, et `curl`)
   ```bash
   php -S localhost:8000
   ```
   Puis ouvrir `http://localhost:8000/index.html`

4. Le compte promoteur par défaut est inséré dans `database.sql` — **remplacez immédiatement** le hash du mot de passe par :
   ```php
   php -r "echo password_hash('votre_mot_de_passe', PASSWORD_DEFAULT);"
   ```
   et mettez à jour la ligne `INSERT INTO users ...` ou la ligne en base directement.

## Structure des fichiers

```
study-easy/
├── index.html                 → Choix du rôle (étudiant / enseignant / promoteur)
├── login.html                 → Connexion
├── register.html              → Inscription (étudiant / enseignant)
├── etudiant.html               → Tableau de bord étudiant (progression, cours, évaluations)
├── enseignant.html             → Tableau de bord enseignant (cours, leçons, évaluations)
├── promoteur.html              → Tableau de bord promoteur (modules, users, certificats)
├── certificat.html             → Affichage du certificat + QR code
├── verifier_certificat.html    → Vérification publique d'un certificat (scan QR code)
├── css/style.css               → Thème bleu nuit unique
├── js/main.js                  → Fonctions AJAX communes
└── php/
    ├── config.php               → Connexions MySQL / Neon / Cloudinary
    ├── database.sql             → Schéma MySQL complet
    └── api/                     → Un fichier PHP par action (register, login, cours, leçons, évaluations, certificats...)
```

## Logique de progression

- Chaque leçon publiée est suivie d'une évaluation (QCM).
- La progression d'un cours = moyenne des notes obtenues aux évaluations déjà passées, rapportée au nombre total d'évaluations du cours.
- Un module est considéré comme **validé** quand la moyenne des cours publiés du module atteint **70%** (seuil modifiable dans `get_student_dashboard.php` et `request_certificate.php`).
- Une fois validé, l'étudiant peut **demander** son certificat → passe en statut `en_attente` → le **promoteur** l'approuve ou le refuse depuis son tableau de bord → une fois approuvé, le certificat (avec QR code de vérification) devient accessible et imprimable.
