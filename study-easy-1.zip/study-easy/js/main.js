/* =========================================================
   STUDY-EASY — main.js
   Fonctions AJAX communes à toutes les pages
   ========================================================= */

const API_BASE = 'php/api/';

/**
 * Effectue une requête AJAX (fetch) vers l'API PHP.
 * @param {string} endpoint - nom du fichier PHP (ex: 'login.php')
 * @param {string} method - 'GET' ou 'POST'
 * @param {FormData|Object|null} data - données à envoyer
 */
async function appelApi(endpoint, method = 'GET', data = null) {
    const options = { method, credentials: 'same-origin' };

    if (data instanceof FormData) {
        options.body = data;
    } else if (data && typeof data === 'object') {
        options.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
        options.body = new URLSearchParams(data).toString();
    }

    try {
        const response = await fetch(API_BASE + endpoint, options);
        return await response.json();
    } catch (err) {
        console.error('Erreur AJAX:', err);
        return { success: false, message: 'Erreur réseau. Veuillez réessayer.' };
    }
}

/** Envoie du JSON brut (utilisé pour les évaluations avec structure complexe) */
async function appelApiJson(endpoint, jsonPayload) {
    const form = new FormData();
    form.append('data', JSON.stringify(jsonPayload));
    return appelApi(endpoint, 'POST', form);
}

/** Affiche un message de succès/erreur dans un conteneur donné */
function afficherMessage(elementId, message, type = 'erreur') {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.textContent = message;
    el.className = 'message ' + type;
    el.style.display = 'block';
}

/** Ouvre / ferme une modale par son id */
function ouvrirModal(id) {
    document.getElementById(id).classList.add('active');
}
function fermerModal(id) {
    document.getElementById(id).classList.remove('active');
}

/** Gestion des onglets génériques (data-tab) */
function initTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.tab;
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(target).classList.add('active');
        });
    });
}

/** Déconnexion commune */
async function deconnecter() {
    const res = await appelApi('logout.php', 'POST');
    if (res.success) {
        window.location.href = 'index.html';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const btnLogout = document.getElementById('btn-logout');
    if (btnLogout) btnLogout.addEventListener('click', deconnecter);
    initTabs();
});
