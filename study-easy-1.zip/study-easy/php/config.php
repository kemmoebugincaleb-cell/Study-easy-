<?php
/**
 * config.php
 * Configuration centrale de STUDY-EASY
 * - MySQL  : toutes les données relationnelles (users, cours, notes...)
 * - Neon   : PostgreSQL serverless -> stockage des fichiers PDF
 * - Cloudinary : stockage des vidéos
 *
 * ⚠️ Remplacez les valeurs ci-dessous par vos identifiants réels
 * avant la mise en production. Ne jamais versionner ce fichier
 * avec de vrais secrets (utilisez des variables d'environnement).
 */

session_start();
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 0); // passer à 1 en dev uniquement

// ---------------------------------------------------------
// 1) CONNEXION MYSQL (PDO)
// ---------------------------------------------------------
define('MYSQL_HOST', getenv('MYSQL_HOST') ?: 'localhost');
define('MYSQL_DB',   getenv('MYSQL_DB')   ?: 'study_easy');
define('MYSQL_USER', getenv('MYSQL_USER') ?: 'root');
define('MYSQL_PASS', getenv('MYSQL_PASS') ?: '');

function getMysqlConnection() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . MYSQL_HOST . ";dbname=" . MYSQL_DB . ";charset=utf8mb4",
                MYSQL_USER,
                MYSQL_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Erreur connexion MySQL: ' . $e->getMessage()]);
            exit;
        }
    }
    return $pdo;
}

// ---------------------------------------------------------
// 2) CONNEXION NEON (PostgreSQL) -> stockage des PDF
//    Neon fournit une chaîne de connexion du type :
//    postgres://user:password@ep-xxxx.neon.tech/dbname?sslmode=require
// ---------------------------------------------------------
define('NEON_HOST', getenv('NEON_HOST') ?: 'ep-example-123456.eu-central-1.aws.neon.tech');
define('NEON_DB',   getenv('NEON_DB')   ?: 'study_easy_pdfs');
define('NEON_USER', getenv('NEON_USER') ?: 'neon_user');
define('NEON_PASS', getenv('NEON_PASS') ?: 'neon_password');

function getNeonConnection() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "pgsql:host=" . NEON_HOST . ";port=5432;dbname=" . NEON_DB . ";sslmode=require",
                NEON_USER,
                NEON_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Erreur connexion Neon: ' . $e->getMessage()]);
            exit;
        }
    }
    return $pdo;
}

/**
 * Crée la table de stockage des PDF sur Neon si elle n'existe pas encore.
 * A exécuter une fois (ou appeler au démarrage).
 */
function ensureNeonSchema() {
    $pdo = getNeonConnection();
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS documents_pdf (
            id SERIAL PRIMARY KEY,
            nom_fichier VARCHAR(255) NOT NULL,
            contenu BYTEA NOT NULL,
            taille_octets INTEGER NOT NULL,
            date_upload TIMESTAMP DEFAULT NOW()
        );
    ");
}

// ---------------------------------------------------------
// 3) CLOUDINARY (upload vidéo via API REST, sans SDK)
// ---------------------------------------------------------
define('CLOUDINARY_CLOUD_NAME', getenv('CLOUDINARY_CLOUD_NAME') ?: 'votre_cloud_name');
define('CLOUDINARY_API_KEY',    getenv('CLOUDINARY_API_KEY')    ?: 'votre_api_key');
define('CLOUDINARY_API_SECRET', getenv('CLOUDINARY_API_SECRET') ?: 'votre_api_secret');

/**
 * Upload une vidéo vers Cloudinary via une requête signée.
 * $filePath : chemin temporaire du fichier uploadé ($_FILES[...]['tmp_name'])
 * Retourne un tableau ['secure_url' => ..., 'public_id' => ...] ou false
 */
function uploadVideoToCloudinary($filePath) {
    $timestamp = time();
    $paramsToSign = "timestamp=$timestamp";
    $signature = sha1($paramsToSign . CLOUDINARY_API_SECRET);

    $url = "https://api.cloudinary.com/v1_1/" . CLOUDINARY_CLOUD_NAME . "/video/upload";

    $postFields = [
        'file' => new CURLFile($filePath),
        'timestamp' => $timestamp,
        'api_key' => CLOUDINARY_API_KEY,
        'signature' => $signature,
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        return false;
    }

    $data = json_decode($response, true);
    if (isset($data['secure_url'])) {
        return ['secure_url' => $data['secure_url'], 'public_id' => $data['public_id']];
    }
    return false;
}

// ---------------------------------------------------------
// Fonctions utilitaires communes
// ---------------------------------------------------------
function jsonResponse($success, $message = '', $data = []) {
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit;
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'Non authentifié. Veuillez vous connecter.');
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        http_response_code(403);
        jsonResponse(false, 'Accès refusé pour ce rôle.');
    }
}
