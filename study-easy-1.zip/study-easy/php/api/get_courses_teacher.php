<?php
require_once __DIR__ . '/../config.php';
requireRole('enseignant');

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("
    SELECT c.id, c.titre, c.description, c.statut, c.date_creation,
           m.titre AS module_titre,
           (SELECT COUNT(*) FROM lecons l WHERE l.cours_id = c.id) AS nb_lecons
    FROM cours c
    JOIN modules m ON m.id = c.module_id
    WHERE c.enseignant_id = ?
    ORDER BY c.date_creation DESC
");
$stmt->execute([$_SESSION['user_id']]);
$cours = $stmt->fetchAll();

jsonResponse(true, '', ['cours' => $cours]);
