<?php
require_once __DIR__ . '/../config.php';
requireRole('etudiant');

$pdo = getMysqlConnection();
$etudiantId = $_SESSION['user_id'];

// Tous les modules avec les cours publiés qu'ils contiennent
$modules = $pdo->query("SELECT id, titre, description FROM modules ORDER BY titre ASC")->fetchAll();

foreach ($modules as &$module) {
    $stmt = $pdo->prepare("
        SELECT c.id, c.titre, c.description,
               COALESCE(p.pourcentage, 0) AS progression
        FROM cours c
        LEFT JOIN progression p ON p.cours_id = c.id AND p.etudiant_id = ?
        WHERE c.module_id = ? AND c.statut = 'publie'
        ORDER BY c.date_creation ASC
    ");
    $stmt->execute([$etudiantId, $module['id']]);
    $module['cours'] = $stmt->fetchAll();

    // Progression moyenne du module = moyenne des cours du module
    $total = 0;
    $count = count($module['cours']);
    foreach ($module['cours'] as $c) {
        $total += $c['progression'];
    }
    $module['progression_module'] = $count > 0 ? round($total / $count, 2) : 0;

    // Un module est "validé" si progression_module >= 70%
    $module['valide'] = $module['progression_module'] >= 70;

    // Vérifie si un certificat existe déjà pour ce module
    $stmtCert = $pdo->prepare("SELECT statut, code_unique FROM certificats WHERE etudiant_id = ? AND module_id = ?");
    $stmtCert->execute([$etudiantId, $module['id']]);
    $cert = $stmtCert->fetch();
    $module['certificat'] = $cert ?: null;
}
unset($module);

jsonResponse(true, '', [
    'modules' => $modules,
    'etudiant' => ['nom' => $_SESSION['nom'], 'prenom' => $_SESSION['prenom']]
]);
