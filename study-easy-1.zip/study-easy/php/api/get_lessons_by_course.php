<?php
require_once __DIR__ . '/../config.php';
requireLogin();

$coursId = (int)($_GET['cours_id'] ?? 0);
if ($coursId <= 0) {
    jsonResponse(false, 'Cours invalide.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("SELECT id, titre, type_contenu, ordre FROM lecons WHERE cours_id = ? ORDER BY ordre ASC");
$stmt->execute([$coursId]);
$lecons = $stmt->fetchAll();

jsonResponse(true, '', ['lecons' => $lecons]);
