<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Méthode non autorisée.');
}

$nom = trim($_POST['nom'] ?? '');
$prenom = trim($_POST['prenom'] ?? '');
$email = trim($_POST['email'] ?? '');
$motDePasse = $_POST['mot_de_passe'] ?? '';
$role = $_POST['role'] ?? '';

if (!in_array($role, ['etudiant', 'enseignant', 'promoteur'])) {
    jsonResponse(false, 'Rôle invalide.');
}
if ($nom === '' || $prenom === '' || $email === '' || $motDePasse === '') {
    jsonResponse(false, 'Tous les champs sont obligatoires.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(false, 'Adresse email invalide.');
}
if (strlen($motDePasse) < 6) {
    jsonResponse(false, 'Le mot de passe doit contenir au moins 6 caractères.');
}

$pdo = getMysqlConnection();

// Vérifier l'unicité de l'email
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    jsonResponse(false, 'Cet email est déjà utilisé.');
}

$hash = password_hash($motDePasse, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO users (nom, prenom, email, mot_de_passe, role) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$nom, $prenom, $email, $hash, $role]);

jsonResponse(true, 'Inscription réussie. Vous pouvez maintenant vous connecter.');
