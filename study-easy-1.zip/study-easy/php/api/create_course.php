<?php
require_once __DIR__ . '/../config.php';
requireRole('enseignant');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Méthode non autorisée.');
}

$titre = trim($_POST['titre'] ?? '');
$description = trim($_POST['description'] ?? '');
$moduleId = (int)($_POST['module_id'] ?? 0);

if ($titre === '' || $moduleId <= 0) {
    jsonResponse(false, 'Le titre et le module sont obligatoires.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("INSERT INTO cours (module_id, enseignant_id, titre, description, statut) VALUES (?, ?, ?, ?, 'brouillon')");
$stmt->execute([$moduleId, $_SESSION['user_id'], $titre, $description]);

jsonResponse(true, 'Cours créé en brouillon.', ['cours_id' => $pdo->lastInsertId()]);
