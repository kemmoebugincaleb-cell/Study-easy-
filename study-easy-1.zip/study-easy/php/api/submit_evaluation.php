<?php
require_once __DIR__ . '/../config.php';
requireRole('etudiant');

/**
 * Payload attendu (JSON) :
 * {
 *   "evaluation_id": 5,
 *   "reponses": { "question_id": "reponse_id", ... }
 * }
 */
$raw = $_POST['data'] ?? file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!$payload || !isset($payload['evaluation_id'], $payload['reponses'])) {
    jsonResponse(false, 'Données invalides.');
}

$evaluationId = (int)$payload['evaluation_id'];
$reponsesEtudiant = $payload['reponses']; // [question_id => reponse_id]
$etudiantId = $_SESSION['user_id'];

$pdo = getMysqlConnection();

// Récupère la leçon / le cours liés à cette évaluation
$stmt = $pdo->prepare("
    SELECT e.note_minimale, l.cours_id
    FROM evaluations e
    JOIN lecons l ON l.id = e.lecon_id
    WHERE e.id = ?
");
$stmt->execute([$evaluationId]);
$eval = $stmt->fetch();
if (!$eval) {
    jsonResponse(false, 'Évaluation introuvable.');
}

// Récupère toutes les questions + la bonne réponse
$stmt = $pdo->prepare("SELECT id FROM questions WHERE evaluation_id = ?");
$stmt->execute([$evaluationId]);
$questions = $stmt->fetchAll();
$totalQuestions = count($questions);

if ($totalQuestions === 0) {
    jsonResponse(false, 'Cette évaluation ne contient aucune question.');
}

$bonnesReponses = 0;
foreach ($questions as $q) {
    $qId = $q['id'];
    $stmtCorrect = $pdo->prepare("SELECT id FROM reponses WHERE question_id = ? AND est_correcte = 1");
    $stmtCorrect->execute([$qId]);
    $correct = $stmtCorrect->fetch();

    if ($correct && isset($reponsesEtudiant[$qId]) && (int)$reponsesEtudiant[$qId] === (int)$correct['id']) {
        $bonnesReponses++;
    }
}

$note = round(($bonnesReponses / $totalQuestions) * 100);
$reussie = $note >= $eval['note_minimale'] ? 1 : 0;

// Enregistre (ou met à jour) le résultat
$stmt = $pdo->prepare("
    INSERT INTO resultats_evaluations (etudiant_id, evaluation_id, note, reussie)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE note = VALUES(note), reussie = VALUES(reussie), date_passage = NOW()
");
$stmt->execute([$etudiantId, $evaluationId, $note, $reussie]);

// ---- Recalcule la progression globale du cours ----
$coursId = $eval['cours_id'];

// Nombre total de leçons du cours qui possèdent une évaluation
$stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM evaluations e
    JOIN lecons l ON l.id = e.lecon_id
    WHERE l.cours_id = ?
");
$stmt->execute([$coursId]);
$totalEvaluations = $stmt->fetch()['total'];

// Moyenne des notes obtenues par l'étudiant sur ces évaluations (0 si pas encore passées)
$stmt = $pdo->prepare("
    SELECT AVG(re.note) AS moyenne, COUNT(re.id) AS passees
    FROM evaluations e
    JOIN lecons l ON l.id = e.lecon_id
    LEFT JOIN resultats_evaluations re ON re.evaluation_id = e.id AND re.etudiant_id = ?
    WHERE l.cours_id = ?
");
$stmt->execute([$etudiantId, $coursId]);
$res = $stmt->fetch();

// Progression = (somme des notes obtenues) / (nb total d'évaluations * 100)
$stmt = $pdo->prepare("
    SELECT COALESCE(SUM(re.note), 0) AS somme_notes
    FROM evaluations e
    JOIN lecons l ON l.id = e.lecon_id
    LEFT JOIN resultats_evaluations re ON re.evaluation_id = e.id AND re.etudiant_id = ?
    WHERE l.cours_id = ?
");
$stmt->execute([$etudiantId, $coursId]);
$sommeNotes = $stmt->fetch()['somme_notes'];

$progression = $totalEvaluations > 0 ? round($sommeNotes / ($totalEvaluations * 100) * 100, 2) : 0;

$stmt = $pdo->prepare("
    INSERT INTO progression (etudiant_id, cours_id, pourcentage)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE pourcentage = VALUES(pourcentage), derniere_maj = NOW()
");
$stmt->execute([$etudiantId, $coursId, $progression]);

jsonResponse(true, $reussie ? 'Évaluation réussie !' : 'Évaluation non réussie, vous pouvez réessayer.', [
    'note' => $note,
    'reussie' => (bool)$reussie,
    'progression_cours' => $progression
]);
