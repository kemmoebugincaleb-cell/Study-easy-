<?php
require_once __DIR__ . '/../config.php';
// Endpoint volontairement PUBLIC (pas de requireLogin) : un QR code peut être
// scanné par n'importe qui pour vérifier l'authenticité d'un certificat.
// On ne renvoie que des informations non sensibles (aucun mot de passe, aucun email).

$code = trim($_GET['code'] ?? '');
if ($code === '') {
    jsonResponse(false, 'Code de certificat manquant.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("
    SELECT cert.statut, cert.date_approbation,
           u.nom, u.prenom,
           m.titre AS module_titre
    FROM certificats cert
    JOIN users u ON u.id = cert.etudiant_id
    JOIN modules m ON m.id = cert.module_id
    WHERE cert.code_unique = ?
");
$stmt->execute([$code]);
$cert = $stmt->fetch();

if (!$cert || $cert['statut'] !== 'approuve') {
    jsonResponse(false, 'Certificat introuvable ou non approuvé.');
}

jsonResponse(true, '', ['certificat' => $cert]);
