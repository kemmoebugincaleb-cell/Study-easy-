<?php
require_once __DIR__ . '/../config.php';
requireRole('enseignant');

$coursId = (int)($_POST['cours_id'] ?? 0);
if ($coursId <= 0) {
    jsonResponse(false, 'Cours invalide.');
}

$pdo = getMysqlConnection();

// Vérifie que le cours appartient bien à l'enseignant et possède au moins une leçon
$stmt = $pdo->prepare("SELECT id FROM cours WHERE id = ? AND enseignant_id = ?");
$stmt->execute([$coursId, $_SESSION['user_id']]);
if (!$stmt->fetch()) {
    jsonResponse(false, 'Ce cours ne vous appartient pas.');
}

$stmt = $pdo->prepare("SELECT COUNT(*) AS nb FROM lecons WHERE cours_id = ?");
$stmt->execute([$coursId]);
if ($stmt->fetch()['nb'] == 0) {
    jsonResponse(false, 'Ajoutez au moins une leçon avant de publier.');
}

$stmt = $pdo->prepare("UPDATE cours SET statut = 'publie' WHERE id = ?");
$stmt->execute([$coursId]);

jsonResponse(true, 'Cours publié avec succès.');
