<?php
require_once __DIR__ . '/../config.php';
requireRole('promoteur');

$titre = trim($_POST['titre'] ?? '');
$description = trim($_POST['description'] ?? '');

if ($titre === '') {
    jsonResponse(false, 'Le titre du module est obligatoire.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("INSERT INTO modules (titre, description, cree_par) VALUES (?, ?, ?)");
$stmt->execute([$titre, $description, $_SESSION['user_id']]);

jsonResponse(true, 'Module créé avec succès.', ['module_id' => $pdo->lastInsertId()]);
