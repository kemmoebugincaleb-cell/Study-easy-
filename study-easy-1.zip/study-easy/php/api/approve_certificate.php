<?php
require_once __DIR__ . '/../config.php';
requireRole('promoteur');

$certificatId = (int)($_POST['certificat_id'] ?? 0);
$decision = $_POST['decision'] ?? ''; // 'approuve' ou 'refuse'

if ($certificatId <= 0 || !in_array($decision, ['approuve', 'refuse'])) {
    jsonResponse(false, 'Requête invalide.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("
    UPDATE certificats
    SET statut = ?, approuve_par = ?, date_approbation = NOW()
    WHERE id = ?
");
$stmt->execute([$decision, $_SESSION['user_id'], $certificatId]);

jsonResponse(true, $decision === 'approuve' ? 'Certificat approuvé.' : 'Certificat refusé.');
