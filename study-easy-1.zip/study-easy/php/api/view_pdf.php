<?php
require_once __DIR__ . '/../config.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    exit('ID de document invalide.');
}

$neonPdo = getNeonConnection();
$stmt = $neonPdo->prepare("SELECT nom_fichier, contenu FROM documents_pdf WHERE id = ?");
$stmt->execute([$id]);
$doc = $stmt->fetch();

if (!$doc) {
    http_response_code(404);
    exit('Document introuvable.');
}

// On repasse en mode "binaire" (config.php force le header JSON par défaut)
header_remove('Content-Type');
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . basename($doc['nom_fichier']) . '"');
// $doc['contenu'] est retourné en flux binaire ("resource") ou string selon le driver pgsql
echo is_resource($doc['contenu']) ? stream_get_contents($doc['contenu']) : $doc['contenu'];
exit;
