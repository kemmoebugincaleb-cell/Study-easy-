<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Méthode non autorisée.');
}

$email = trim($_POST['email'] ?? '');
$motDePasse = $_POST['mot_de_passe'] ?? '';
$roleAttendu = $_POST['role'] ?? '';

if ($email === '' || $motDePasse === '' || $roleAttendu === '') {
    jsonResponse(false, 'Veuillez remplir tous les champs.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = ?");
$stmt->execute([$email, $roleAttendu]);
$user = $stmt->fetch();

if (!$user || !password_verify($motDePasse, $user['mot_de_passe'])) {
    jsonResponse(false, 'Identifiants incorrects ou rôle incorrect.');
}

if (!$user['actif']) {
    jsonResponse(false, 'Ce compte est désactivé.');
}

// Création de la session
$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = $user['role'];
$_SESSION['nom'] = $user['nom'];
$_SESSION['prenom'] = $user['prenom'];

$redirects = [
    'etudiant' => 'etudiant.html',
    'enseignant' => 'enseignant.html',
    'promoteur' => 'promoteur.html',
];

jsonResponse(true, 'Connexion réussie.', [
    'redirect' => $redirects[$user['role']],
    'user' => [
        'nom' => $user['nom'],
        'prenom' => $user['prenom'],
        'role' => $user['role'],
    ]
]);
