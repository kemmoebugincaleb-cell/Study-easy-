<?php
require_once __DIR__ . '/../config.php';
requireRole('etudiant');

$moduleId = (int)($_POST['module_id'] ?? 0);
$etudiantId = $_SESSION['user_id'];

if ($moduleId <= 0) {
    jsonResponse(false, 'Module invalide.');
}

$pdo = getMysqlConnection();

// Vérifie que le module est bien validé (moyenne des cours publiés >= 70%)
$stmt = $pdo->prepare("
    SELECT COALESCE(AVG(p.pourcentage), 0) AS moyenne
    FROM cours c
    LEFT JOIN progression p ON p.cours_id = c.id AND p.etudiant_id = ?
    WHERE c.module_id = ? AND c.statut = 'publie'
");
$stmt->execute([$etudiantId, $moduleId]);
$moyenne = $stmt->fetch()['moyenne'];

if ($moyenne < 70) {
    jsonResponse(false, 'Le module n\'est pas encore validé (moyenne actuelle : ' . round($moyenne) . '%).');
}

// Vérifie qu'un certificat n'existe pas déjà
$stmt = $pdo->prepare("SELECT id, statut FROM certificats WHERE etudiant_id = ? AND module_id = ?");
$stmt->execute([$etudiantId, $moduleId]);
$existant = $stmt->fetch();

if ($existant) {
    jsonResponse(true, 'Une demande de certificat existe déjà.', ['statut' => $existant['statut']]);
}

$codeUnique = bin2hex(random_bytes(16)); // utilisé pour le QR code / vérification publique

$stmt = $pdo->prepare("INSERT INTO certificats (code_unique, etudiant_id, module_id, statut) VALUES (?, ?, ?, 'en_attente')");
$stmt->execute([$codeUnique, $etudiantId, $moduleId]);

jsonResponse(true, 'Demande de certificat envoyée au promoteur pour approbation.', ['code_unique' => $codeUnique]);
