<?php
require_once __DIR__ . '/../config.php';
requireRole('enseignant');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Méthode non autorisée.');
}

$coursId = (int)($_POST['cours_id'] ?? 0);
$titre = trim($_POST['titre'] ?? '');
$typeContenu = $_POST['type_contenu'] ?? '';

if ($coursId <= 0 || $titre === '' || !in_array($typeContenu, ['pdf', 'video'])) {
    jsonResponse(false, 'Données invalides.');
}

$pdo = getMysqlConnection();

// Vérifier que le cours appartient à l'enseignant connecté
$stmt = $pdo->prepare("SELECT id FROM cours WHERE id = ? AND enseignant_id = ?");
$stmt->execute([$coursId, $_SESSION['user_id']]);
if (!$stmt->fetch()) {
    jsonResponse(false, 'Ce cours ne vous appartient pas.');
}

if (!isset($_FILES['fichier']) || $_FILES['fichier']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(false, 'Aucun fichier valide reçu.');
}

$cloudinaryUrl = null;
$cloudinaryPublicId = null;
$neonPdfId = null;

if ($typeContenu === 'video') {
    // ---- Upload vers CLOUDINARY ----
    $result = uploadVideoToCloudinary($_FILES['fichier']['tmp_name']);
    if (!$result) {
        jsonResponse(false, "Échec de l'upload vidéo vers Cloudinary.");
    }
    $cloudinaryUrl = $result['secure_url'];
    $cloudinaryPublicId = $result['public_id'];
} else {
    // ---- Upload vers NEON (PostgreSQL, stockage en BYTEA) ----
    $ext = strtolower(pathinfo($_FILES['fichier']['name'], PATHINFO_EXTENSION));
    if ($ext !== 'pdf') {
        jsonResponse(false, 'Le fichier doit être un PDF.');
    }
    $contenu = file_get_contents($_FILES['fichier']['tmp_name']);

    ensureNeonSchema();
    $neonPdo = getNeonConnection();
    $stmtPdf = $neonPdo->prepare("INSERT INTO documents_pdf (nom_fichier, contenu, taille_octets) VALUES (?, ?, ?) RETURNING id");
    $stmtPdf->execute([$_FILES['fichier']['name'], $contenu, strlen($contenu)]);
    $neonPdfId = $stmtPdf->fetch()['id'];
}

// Ordre de la leçon = position suivante dans le cours
$stmt = $pdo->prepare("SELECT COALESCE(MAX(ordre), 0) + 1 AS next_ordre FROM lecons WHERE cours_id = ?");
$stmt->execute([$coursId]);
$ordre = $stmt->fetch()['next_ordre'];

$stmt = $pdo->prepare("
    INSERT INTO lecons (cours_id, titre, type_contenu, cloudinary_url, cloudinary_public_id, neon_pdf_id, ordre)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([$coursId, $titre, $typeContenu, $cloudinaryUrl, $cloudinaryPublicId, $neonPdfId, $ordre]);

jsonResponse(true, 'Leçon ajoutée avec succès.', ['lecon_id' => $pdo->lastInsertId()]);
