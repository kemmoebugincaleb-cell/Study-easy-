<?php
require_once __DIR__ . '/../config.php';
requireRole('enseignant');

/**
 * Format JSON attendu dans $_POST['data'] :
 * {
 *   "lecon_id": 12,
 *   "titre": "Évaluation - Leçon 1",
 *   "note_minimale": 50,
 *   "questions": [
 *     { "enonce": "...", "reponses": [ {"texte": "...", "correcte": true}, ... ] },
 *     ...
 *   ]
 * }
 */

$raw = $_POST['data'] ?? file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!$payload || !isset($payload['lecon_id'], $payload['questions'])) {
    jsonResponse(false, 'Données invalides.');
}

$leconId = (int)$payload['lecon_id'];
$titre = trim($payload['titre'] ?? 'Évaluation');
$noteMin = (int)($payload['note_minimale'] ?? 50);
$questions = $payload['questions'];

if (empty($questions)) {
    jsonResponse(false, 'Ajoutez au moins une question.');
}

$pdo = getMysqlConnection();

// Vérifie que la leçon appartient bien à un cours de l'enseignant connecté
$stmt = $pdo->prepare("
    SELECT l.id FROM lecons l
    JOIN cours c ON c.id = l.cours_id
    WHERE l.id = ? AND c.enseignant_id = ?
");
$stmt->execute([$leconId, $_SESSION['user_id']]);
if (!$stmt->fetch()) {
    jsonResponse(false, 'Cette leçon ne vous appartient pas.');
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO evaluations (lecon_id, titre, note_minimale) VALUES (?, ?, ?)");
    $stmt->execute([$leconId, $titre, $noteMin]);
    $evaluationId = $pdo->lastInsertId();

    $stmtQ = $pdo->prepare("INSERT INTO questions (evaluation_id, enonce) VALUES (?, ?)");
    $stmtR = $pdo->prepare("INSERT INTO reponses (question_id, texte, est_correcte) VALUES (?, ?, ?)");

    foreach ($questions as $q) {
        $stmtQ->execute([$evaluationId, trim($q['enonce'])]);
        $questionId = $pdo->lastInsertId();
        foreach ($q['reponses'] as $r) {
            $stmtR->execute([$questionId, trim($r['texte']), !empty($r['correcte']) ? 1 : 0]);
        }
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    jsonResponse(false, "Erreur lors de la création de l'évaluation: " . $e->getMessage());
}

jsonResponse(true, 'Évaluation créée avec succès.', ['evaluation_id' => $evaluationId]);
