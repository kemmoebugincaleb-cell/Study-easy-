<?php
require_once __DIR__ . '/../config.php';
requireLogin();

$leconId = (int)($_GET['lecon_id'] ?? 0);
if ($leconId <= 0) {
    jsonResponse(false, 'Leçon invalide.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("SELECT * FROM lecons WHERE id = ?");
$stmt->execute([$leconId]);
$lecon = $stmt->fetch();

if (!$lecon) {
    jsonResponse(false, 'Leçon introuvable.');
}

// Récupère l'évaluation associée (avec questions/réponses, sans révéler la bonne réponse)
$stmt = $pdo->prepare("SELECT id, titre, note_minimale FROM evaluations WHERE lecon_id = ?");
$stmt->execute([$leconId]);
$evaluation = $stmt->fetch();

if ($evaluation) {
    $stmtQ = $pdo->prepare("SELECT id, enonce FROM questions WHERE evaluation_id = ?");
    $stmtQ->execute([$evaluation['id']]);
    $questions = $stmtQ->fetchAll();

    foreach ($questions as &$q) {
        $stmtR = $pdo->prepare("SELECT id, texte FROM reponses WHERE question_id = ?");
        $stmtR->execute([$q['id']]);
        $q['reponses'] = $stmtR->fetchAll();
    }
    unset($q);
    $evaluation['questions'] = $questions;
}

// Si type = pdf, on fournit un lien de téléchargement/lecture (proxy Neon)
if ($lecon['type_contenu'] === 'pdf') {
    $lecon['pdf_view_url'] = 'api/view_pdf.php?id=' . $lecon['neon_pdf_id'];
}

jsonResponse(true, '', ['lecon' => $lecon, 'evaluation' => $evaluation]);
