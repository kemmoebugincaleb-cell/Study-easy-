<?php
require_once __DIR__ . '/../config.php';
requireLogin();

$code = trim($_GET['code'] ?? '');
if ($code === '') {
    jsonResponse(false, 'Code de certificat manquant.');
}

$pdo = getMysqlConnection();
$stmt = $pdo->prepare("
    SELECT cert.code_unique, cert.statut, cert.date_obtention, cert.date_approbation,
           u.nom, u.prenom,
           m.titre AS module_titre,
           p.nom AS promoteur_nom, p.prenom AS promoteur_prenom
    FROM certificats cert
    JOIN users u ON u.id = cert.etudiant_id
    JOIN modules m ON m.id = cert.module_id
    LEFT JOIN users p ON p.id = cert.approuve_par
    WHERE cert.code_unique = ?
");
$stmt->execute([$code]);
$cert = $stmt->fetch();

if (!$cert) {
    jsonResponse(false, 'Certificat introuvable.');
}

if ($cert['statut'] !== 'approuve') {
    jsonResponse(false, 'Ce certificat n\'a pas encore été approuvé par le promoteur.', ['statut' => $cert['statut']]);
}

// URL publique de vérification (encodée dans le QR code)
$verifyUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST']
    . dirname(dirname($_SERVER['PHP_SELF'])) . '/../verifier_certificat.html?code=' . urlencode($code);

// QR code généré via l'API publique qrserver (pas de dépendance PHP nécessaire)
$qrCodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' . urlencode($verifyUrl);

jsonResponse(true, '', ['certificat' => $cert, 'qr_code_url' => $qrCodeUrl, 'verify_url' => $verifyUrl]);
