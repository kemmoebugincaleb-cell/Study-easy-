<?php
require_once __DIR__ . '/../config.php';
requireRole('promoteur');

$pdo = getMysqlConnection();

// --- Enseignants + nombre de cours publiés ---
$enseignants = $pdo->query("
    SELECT u.id, u.nom, u.prenom, u.email, u.date_creation,
           COUNT(c.id) AS nb_cours_publies
    FROM users u
    LEFT JOIN cours c ON c.enseignant_id = u.id AND c.statut = 'publie'
    WHERE u.role = 'enseignant'
    GROUP BY u.id
    ORDER BY u.nom ASC
")->fetchAll();

// --- Étudiants + progression moyenne globale ---
$etudiants = $pdo->query("
    SELECT u.id, u.nom, u.prenom, u.email, u.date_creation,
           COALESCE(ROUND(AVG(p.pourcentage), 2), 0) AS progression_moyenne
    FROM users u
    LEFT JOIN progression p ON p.etudiant_id = u.id
    WHERE u.role = 'etudiant'
    GROUP BY u.id
    ORDER BY u.nom ASC
")->fetchAll();

// --- Modules existants ---
$modules = $pdo->query("SELECT id, titre, description, date_creation FROM modules ORDER BY date_creation DESC")->fetchAll();

// --- Certificats en attente d'approbation ---
$certificatsEnAttente = $pdo->query("
    SELECT cert.id, cert.code_unique, cert.date_obtention,
           u.nom, u.prenom, m.titre AS module_titre
    FROM certificats cert
    JOIN users u ON u.id = cert.etudiant_id
    JOIN modules m ON m.id = cert.module_id
    WHERE cert.statut = 'en_attente'
    ORDER BY cert.date_obtention ASC
")->fetchAll();

jsonResponse(true, '', [
    'enseignants' => $enseignants,
    'etudiants' => $etudiants,
    'modules' => $modules,
    'certificats_en_attente' => $certificatsEnAttente
]);
