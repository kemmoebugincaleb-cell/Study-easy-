<?php
require_once __DIR__ . '/../config.php';
requireLogin();

$pdo = getMysqlConnection();
$stmt = $pdo->query("SELECT id, titre, description FROM modules ORDER BY titre ASC");
$modules = $stmt->fetchAll();

jsonResponse(true, '', ['modules' => $modules]);
