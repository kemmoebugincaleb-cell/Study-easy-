-- =========================================================
-- STUDY-EASY - Schéma MySQL principal
-- (Les fichiers PDF sont stockés à part sur Neon/PostgreSQL,
--  les vidéos sont stockées sur Cloudinary : seules les URLs
--  / identifiants sont conservés ici)
-- =========================================================

CREATE DATABASE IF NOT EXISTS study_easy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE study_easy;

-- ---------------------------------------------------------
-- Utilisateurs (les 3 rôles dans une seule table)
-- ---------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,      -- stocké avec password_hash()
    role ENUM('etudiant','enseignant','promoteur') NOT NULL,
    photo_profil VARCHAR(255) DEFAULT NULL,
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    actif TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Modules de cours (créés par le PROMOTEUR)
-- ---------------------------------------------------------
CREATE TABLE modules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(150) NOT NULL,
    description TEXT,
    cree_par INT NOT NULL,                   -- id du promoteur
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cree_par) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Cours (créés par un ENSEIGNANT, rattachés à un module)
-- ---------------------------------------------------------
CREATE TABLE cours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    module_id INT NOT NULL,
    enseignant_id INT NOT NULL,
    titre VARCHAR(150) NOT NULL,
    description TEXT,
    statut ENUM('brouillon','publie') DEFAULT 'brouillon',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE,
    FOREIGN KEY (enseignant_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Leçons (PDF ou vidéo) - une leçon appartient à un cours
-- ---------------------------------------------------------
CREATE TABLE lecons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cours_id INT NOT NULL,
    titre VARCHAR(150) NOT NULL,
    type_contenu ENUM('pdf','video') NOT NULL,
    -- Si type_contenu = 'video' : URL Cloudinary
    cloudinary_url VARCHAR(500) DEFAULT NULL,
    cloudinary_public_id VARCHAR(255) DEFAULT NULL,
    -- Si type_contenu = 'pdf' : identifiant du document stocké sur Neon (Postgres)
    neon_pdf_id INT DEFAULT NULL,
    ordre INT DEFAULT 0,
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Évaluations (une évaluation = QCM à la fin d'une leçon)
-- ---------------------------------------------------------
CREATE TABLE evaluations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lecon_id INT NOT NULL,
    titre VARCHAR(150) NOT NULL,
    note_minimale INT DEFAULT 50,   -- seuil de réussite en %
    FOREIGN KEY (lecon_id) REFERENCES lecons(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    evaluation_id INT NOT NULL,
    enonce TEXT NOT NULL,
    FOREIGN KEY (evaluation_id) REFERENCES evaluations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE reponses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    texte VARCHAR(255) NOT NULL,
    est_correcte TINYINT(1) DEFAULT 0,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Résultats d'un étudiant à une évaluation
-- ---------------------------------------------------------
CREATE TABLE resultats_evaluations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    evaluation_id INT NOT NULL,
    note INT NOT NULL,              -- note obtenue en %
    reussie TINYINT(1) DEFAULT 0,
    date_passage DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (etudiant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (evaluation_id) REFERENCES evaluations(id) ON DELETE CASCADE,
    UNIQUE KEY unique_passage (etudiant_id, evaluation_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Progression d'un étudiant dans un cours (calculée, mais on
-- garde un cache pour affichage rapide sur le tableau de bord)
-- ---------------------------------------------------------
CREATE TABLE progression (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    cours_id INT NOT NULL,
    pourcentage DECIMAL(5,2) DEFAULT 0.00,
    derniere_maj DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (etudiant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE,
    UNIQUE KEY unique_progression (etudiant_id, cours_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Inscriptions des étudiants aux modules
-- ---------------------------------------------------------
CREATE TABLE inscriptions_modules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    module_id INT NOT NULL,
    date_inscription DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (etudiant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE,
    UNIQUE KEY unique_inscription (etudiant_id, module_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Certificats délivrés (approuvés par le promoteur)
-- ---------------------------------------------------------
CREATE TABLE certificats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code_unique VARCHAR(64) NOT NULL UNIQUE,   -- utilisé dans le QR code
    etudiant_id INT NOT NULL,
    module_id INT NOT NULL,
    approuve_par INT DEFAULT NULL,             -- id du promoteur
    statut ENUM('en_attente','approuve','refuse') DEFAULT 'en_attente',
    date_obtention DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_approbation DATETIME DEFAULT NULL,
    FOREIGN KEY (etudiant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE,
    FOREIGN KEY (approuve_par) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Compte promoteur par défaut (mot de passe : "admin123", à changer)
-- Hash généré avec password_hash('admin123', PASSWORD_DEFAULT)
-- ---------------------------------------------------------
INSERT INTO users (nom, prenom, email, mot_de_passe, role)
VALUES ('Admin', 'Promoteur', '[email protected]',
'$2y$10$examplehashreplaceatinstall1234567890abcdefghijk', 'promoteur');
